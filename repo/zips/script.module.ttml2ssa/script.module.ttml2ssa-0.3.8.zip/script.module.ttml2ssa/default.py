import xbmcaddon
xbmcaddon.Addon('script.module.ttml2ssa').openSettings()
